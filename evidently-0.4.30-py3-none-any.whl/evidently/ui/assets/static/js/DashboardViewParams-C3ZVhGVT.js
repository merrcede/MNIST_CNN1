import{R as a,r as t}from"./vendor-CFh6IQM6.js";const s=a.createContext(null),o=()=>t.useContext(s);export{s as D,o as u};
