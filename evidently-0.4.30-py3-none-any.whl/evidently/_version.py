#!/usr/bin/env python
# coding: utf-8

version_info = (0, 4, 30)
__version__ = ".".join(map(str, version_info))
